# ----------------------------
# Caesar Cipher (Encrypt + Decrypt)
# ----------------------------
def caesar_encrypt(text, shift):
    out = ""
    for c in text:
        if c.isalpha():
            base = ord('A') if c.isupper() else ord('a')
            out += chr((ord(c) - base + shift) % 26 + base)
        else:
            out += c
    return out

def caesar_decrypt(text, shift):
    # Just reverse the shift
    return caesar_encrypt(text, -shift)


# ----------------------------
# Atbash Cipher (Encrypt + Decrypt)
# ----------------------------
def atbash_encrypt(text):
    out = ""
    for c in text:
        if c.isalpha():
            base = ord('A') if c.isupper() else ord('a')
            out += chr(25 - (ord(c) - base) + base)
        else:
            out += c
    return out

def atbash_decrypt(text):
    # Atbash is symmetric: encryption = decryption
    return atbash_encrypt(text)


# ----------------------------
# ROT13 Cipher (Encrypt + Decrypt)
# ----------------------------
def rot13_encrypt(text):
    return caesar_encrypt(text, 13)

def rot13_decrypt(text):
    # ROT13 is also symmetric
    return rot13_encrypt(text)


# ----------------------------
# Example usage
# ----------------------------
msg = "Hello World!"

# Caesar
encrypted_caesar = caesar_encrypt(msg, 3)
decrypted_caesar = caesar_decrypt(encrypted_caesar, 3)

# Atbash
encrypted_atbash = atbash_encrypt(msg)
decrypted_atbash = atbash_decrypt(encrypted_atbash)

# ROT13
encrypted_rot13 = rot13_encrypt(msg)
decrypted_rot13 = rot13_decrypt(encrypted_rot13)

# Print results
print("Original:", msg)
print("\n--- Caesar (+3) ---")
print("Encrypted:", encrypted_caesar)
print("Decrypted:", decrypted_caesar)

print("\n--- Atbash ---")
print("Encrypted:", encrypted_atbash)
print("Decrypted:", decrypted_atbash)

print("\n--- ROT13 ---")
print("Encrypted:", encrypted_rot13)
print("Decrypted:", decrypted_rot13)
