def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

# Keep asking until user enters a prime
while True:
    p = int(input("Prime p: "))
    if is_prime(p):
        break
    print("❌ Not a prime, try again!")

g = int(input("Primitive root g: "))
a = int(input("Alice key: "))
b = int(input("Bob key: "))

A = pow(g, a, p)
B = pow(g, b, p)

print("Alice secret:", pow(B, a, p))
print("Bob secret:  ", pow(A, b, p))

print("Out:", pow(g, a*b, p))
