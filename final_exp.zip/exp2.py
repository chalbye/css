def rail_fence_encrypt(text, rails):
    fence = [''] * rails
    rail, step = 0, 1
    for c in text:
        fence[rail] += c
        rail += step
        if rail == 0 or rail == rails - 1:
            step *= -1
    return ''.join(fence)

def rail_fence_decrypt(cipher, rails):
    # Determine rail pattern
    pattern = list(range(rails)) + list(range(rails-2, 0, -1))
    pos = [pattern[i % len(pattern)] for i in range(len(cipher))]

    # Count chars in each rail
    rail_lengths = [pos.count(r) for r in range(rails)]
    
    # Split cipher text into rails
    rails_data, i = [], 0
    for length in rail_lengths:
        rails_data.append(list(cipher[i:i+length]))
        i += length

    # Rebuild original message
    out = ""
    rail_indices = [0] * rails
    for r in pos:
        out += rails_data[r][rail_indices[r]]
        rail_indices[r] += 1
    return out

# Two-level Rail Fence
def two_level_encrypt(text, rails1, rails2):
    return rail_fence_encrypt(rail_fence_encrypt(text, rails1), rails2)

def two_level_decrypt(cipher, rails1, rails2):
    return rail_fence_decrypt(rail_fence_decrypt(cipher, rails2), rails1)


# Example
msg = "HELLO WORLD"
enc = two_level_encrypt(msg, 3, 2)
dec = two_level_decrypt(enc, 3, 2)

print("Original :", msg)
print("Encrypted:", enc)
print("Decrypted:", dec)
