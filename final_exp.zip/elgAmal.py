def mod_inverse(a, m):
    # Extended Euclidean Algorithm for inverse
    for x in range(1, m):
        if (a * x) % m == 1:
            return x
    return None

# ---- Key Generation ----
p = 467      # prime
g = 2        # primitive root
x = 127      # private key (chosen randomly < p)
y = pow(g, x, p)   # public component

print("Public key (p,g,y):", (p, g, y))
print("Private key (x):", x)

# ---- Encryption ----
m = int(input("Enter message (< p): "))
k = 59   # random session key
c1 = pow(g, k, p)
c2 = (m * pow(y, k, p)) % p
print("Ciphertext:", (c1, c2))

# ---- Decryption ----
s = pow(c1, x, p)
s_inv = mod_inverse(s, p)
decrypted = (c2 * s_inv) % p
print("Decrypted:", decrypted)
