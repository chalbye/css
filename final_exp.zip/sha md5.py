import hashlib

text = input("Enter data: ").encode()

print("Select hashing method:\n1. MD5\n2. SHA-256\n3. Combined (MD5+SHA-256)")
choice = input("Choice: ")

if choice == "1":
    print("MD5:", hashlib.md5(text).hexdigest())
elif choice == "2":
    print("SHA-256:", hashlib.sha256(text).hexdigest())
elif choice == "3":
    md5 = hashlib.md5(text).digest()
    sha = hashlib.sha256(text).digest()
    combined = hashlib.sha256(md5 + sha).hexdigest()
    print("Combined:", combined)
else:
    print("❌ Invalid choice!")



