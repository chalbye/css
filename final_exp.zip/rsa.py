def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def mod_inverse(e, phi):
    d = 1
    while (e * d) % phi != 1:
        d += 1
    return d

# Key Generation
p = int(input("Prime p: "))
q = int(input("Prime q: "))
m = int(input("Message (integer < n): "))

n = p * q
phi = (p - 1) * (q - 1)

# Choose e
e = 3
while gcd(e, phi) != 1:
    e += 2

# Calculate d
d = mod_inverse(e, phi)

print(f"Public key: (e={e}, n={n})")
print(f"Private key: (d={d}, n={n})")

# Encryption
c = pow(m, e, n)
print("Encrypted message:", c)

# Decryption
decrypted = pow(c, d, n)
print("Decrypted message:", decrypted)
